﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BossShoot:  BossActions {
    public float time;
    private float _timer = 0;
    private float _timerShoot = 0;
    public float radius;
    public float numberShoot;
    public GameObject bullet;
    public float timeToShoot;
    public float rotationSpeed;
    public float currentAngle=0;
    EnemyBulletManager bulletManager;
    public Vector3 offsetShoot;
    public float reduceTimeToShoot;
    public float extraRotationSpeed;

    private void Start()
    {
        bulletManager = EnemyBulletManager.instance;
    }


    public override void Begin(Boss boss)
    {
        _timer = 0;
        _timerShoot = 0;
        boss.SetAnimation("Spin", true);
        
}

    public override void Finish(Boss boss)
    {
        _timer = 0;
        _timerShoot = 0;
        boss.SetAnimation("Spin", false);
    }



    public override void BossUpdate(Transform boss,Vector3 playerPosition)
    {
        _timer += Time.deltaTime;
        _timerShoot += Time.deltaTime;

        //boss.LookAt(playerPosition); //TODO hacelro con lerp
        if (_timerShoot > timeToShoot) {
            Shoot(boss.position+ offsetShoot);
            _timerShoot = 0;
        }

    }

    protected void Shoot(Vector3 position)
    {

        currentAngle += rotationSpeed + UnityEngine.Random.Range(-1,1);

        float shootPositionX = position.x + (float)Math.Cos(currentAngle);
        float shootPositionz = position.z + (float)Math.Sin(currentAngle);
        Vector3 shootPosition = new Vector3(shootPositionX, position.y, shootPositionz);
        Vector3 rotation = shootPosition - position;


        var s = EnemyBulletManager.instance.giveMeEnemyBullet();
        s.SetPos(shootPosition).SetDir(Quaternion.LookRotation(rotation)).gameObject.SetActive(true);

    }

    public override void Upgrade()
    {
        rotationSpeed += extraRotationSpeed;
        timeToShoot = timeToShoot- reduceTimeToShoot;
    }
}
