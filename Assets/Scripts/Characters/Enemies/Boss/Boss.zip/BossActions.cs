﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public abstract class BossActions:MonoBehaviour  {
    public virtual void  Begin(Boss boss) {
    }
    public virtual void Finish(Boss boss) {
    }
    public virtual void BossUpdate(Transform boss, Vector3 playerPosition) {
    }
    public virtual void Upgrade(){
    }
}
