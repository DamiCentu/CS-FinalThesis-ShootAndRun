﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Boss : AbstractEnemy, IHittable{
    public float introTime;
    public BossExpansiveWave bossExpansiveWave;
    public BossShoot bossShoot;
    public bossMissiles bossMissile;
    public BossJump bossJump;
    private List<BossActions> actions= new List<BossActions>();
    Animator an;
    public int life = 50;
    int maxLife = 50;
    public List<float> LifePercentActions = new List<float>();
    public List<float> Timers = new List<float>();
    public GameObject player;
    private BossActions currentAction;
    Timer timer;
    Timer timerIntro;
    int index;
    bool inmortal=false;
    public SimpleHealthBar helthBar;
    bool introFinished=false;
    public BoxCollider col;
    public ParticleSystem DeadParticle;
    int stage = 0;
    private float maxLifeChange;

    void Awake()
    {
        maxLife = life;
        actions.Add(bossExpansiveWave);
        actions.Add(bossMissile);
        actions.Add(bossShoot);
        actions.Add(bossJump);
        an = GetComponent<Animator>();
        index = 0;
        timerIntro = new Timer(introTime, FinishiIntro);
        currentAction = actions[0];
        currentAction.Begin(this);
        player = ((Player)FindObjectOfType(typeof(Player))).gameObject;
        transform.LookAt(player.transform.position);

        col = this.GetComponent<BoxCollider>();
        DeadParticle =GameObject.Find("ParticleExplosion").GetComponent<ParticleSystem>();
        UpdateBossLife();
    }

    private void FinishiIntro()
    {
        
        timer = new Timer(Timers[index], NextAction);
        introFinished = true;
        print("lalal");
    }



    private void UpdateBossLife()
    {

        object[] container = new object[2];
        container[0] = life;
        container[1] = maxLife;

        EventManager.instance.ExecuteEvent(Constants.UPDATE_BOSS_LIFE, container);
    }

    internal void SetAnimation(string name, bool value)
    {
        an.SetBool(name, value);
       
    }

    private void NextAction()
    {
        print("next");
        index++;
        if (index >= LifePercentActions.Count)
        {
            index = 0;
            Upgrade();
        }

        currentAction.Finish(this);
        currentAction = actions[index]; 
        currentAction.Begin(this);
        maxLifeChange = LifePercentActions[index];
        timer = new Timer(Timers[index], NextAction);
        //timer.Reset(LifePercentActions[index]);
    }

    private void Upgrade()
    {
        stage++;
        UpgradeAction();
    }



    private void UpgradeAction()
    {
        foreach (var action in actions)
        {
            action.Upgrade();
        }
    }

    void Update () {
        if (!introFinished) {
            timerIntro.CheckAndRun();
        }
        if (!isDead() && introFinished) {
            currentAction.BossUpdate(transform, player.transform.position);
            if (life < maxLifeChange || timer.CheckAndRun()) {
                NextAction();
            }
	    }
   }

    void IHittable.OnHit(int damage) {
        if (!inmortal) {
            life -= damage;
            StartCoroutine(OnHitRoutine()); 
            UpdateBossLife();
            if (isDead()) {
                currentAction.Finish(this);
                SetAnimation("Die", true);
                StartCoroutine(Dead());
            }
        }
    }

    IEnumerator Dead() {
        yield return new WaitForSeconds(2);
        DeadParticle.transform.position = this.transform.position;
        DeadParticle.gameObject.SetActive(true);
        DeadParticle.Play();
        EventManager.instance.ExecuteEvent(Constants.BOSS_DESTROYED);
        Destroy(this.gameObject);
    }

    bool isDead() {
        return life <= 0;
    }

    public void SetInmortal(bool v) {
        inmortal = v;
    }
}
